# User Feedback Plugin

Plugin allows each user to give a rating and feedback to other fellow community members.

For more information, please see: https://meta.discourse.org/t/discourse-user-feedback/219002
